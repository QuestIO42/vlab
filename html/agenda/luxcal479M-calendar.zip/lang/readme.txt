======================================================================
               LuxCal Event Calendar Language Files
======================================================================

The LuxCal event calendar is a LuxSoft product - http://www.luxsoft.eu


Per language the following files should be uploaded to the 'lang/'- 
directory of your LuxCal installation:

  ai-{language}.php,               (administrator interface texts)
  ui-{language}.php,               (calendar user interface texts)
  ug-{language}.php and            (calendar's user guide ("help")
  ug-layout.png                    (image shared by all languages)


Note: {language}, including the braces, is the concerned language.


 After uploading the files, the language {language} can be selected
 from the LuxCal settings page and, if enabled on the Settings page,
 users can select the language from the language drop-down menu on
 the calendar's navigation bar.


=====================================================================
=  IF YOU CORRECT ERRORS, FURTHER TRANSLATE UNTRANSLATED TEXTS, OR  =
=  CREATE A SET OF FILES FOR A NEW LANGUAGE, PLEASE SEND A COPY OF  =
=  THE UPDATED/NEW FILE(S) TO: rb@luxsoft.eu                        =
=====================================================================